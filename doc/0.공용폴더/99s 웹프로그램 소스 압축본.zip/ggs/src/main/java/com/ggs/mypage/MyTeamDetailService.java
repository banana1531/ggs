package com.ggs.mypage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ggs.DAO.TeamInfoDAO;
import com.ggs.DTO.TeamInfoDTO;

@Service
public class MyTeamDetailService {
	
}
